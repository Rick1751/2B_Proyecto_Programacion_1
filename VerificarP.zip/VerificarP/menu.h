#ifndef MENU_H
#define MENU_H

//Menu principal
void menuPrincipal();
//Menu Fallas 
void menuFallas();
void registrarMultas();
void registrarCantidadFallas();

#endif
