#include <stdio.h>
#include "menu.h"

void menuPrincipal() {
	
	printf("=== Sistema de Matriculaci�n Vehicular ===\n");
	printf("1. Registrar datos del propietario\n");
	printf("2. Registrar caracter�sticas del veh�culo\n");
	printf("3. Registro de fallas\n");
	printf("4. Registro de multas\n");
	printf("5. Determinar cantidad de fallas\n");
	printf("6. Generar matr�cula\n");
	printf("7. Generar valores de cobro\n");
	printf("8. Salir\n");
}


void menuFallas() {
	int tipoFalla;
	do {
		printf("\n--- Ha ingresado al sistema de registro de fallas ---\n");
		printf("1. Falla en la carrocer�a del veh�culo\n");
		printf("2. Falla en la pintura del veh�culo\n");
		printf("3. Falla en el sistema de puertas\n");
		printf("4. Falla en el sistema de luces\n");
		printf("5. Falla en los neum�ticos\n");
		printf("6. Falla en el sistema de seguridad\n");
		printf("7. Falla en la caja de cambios\n");
		printf("8. Falla en el sistema de frenos\n");
		printf("9. Falla en la bater�a\n");
		printf("10. Falla en el motor\n");
		printf("11. Falla en los sistemas de aire\n");
		printf("12. Salir\n");
		printf("Ingrese el tipo de falla: ");
		scanf("%d", &tipoFalla);
		
		if (tipoFalla >= 1 && tipoFalla <= 11) {
			printf("Falla registrada con �xito.\n");
		}
		
	} while (tipoFalla != 12);
	
	printf("Gracias por la informaci�n. Puede continuar con la matriculaci�n.\n");
}

void registrarMultas() {
	int cantidadMultas, multasPagadas;
	printf("\n--- Ha ingresado al sistema de registro de multas ---\n");
	printf("Ingrese la cantidad de multas del veh�culo: ");
	scanf("%d", &cantidadMultas);
	printf("Ingrese el n�mero de multas pagadas: ");
	scanf("%d", &multasPagadas);
	printf("Gracias por la informaci�n. Puede continuar con la matriculaci�n.\n");
}

void registrarCantidadFallas() {
	int cantidadFallas;
	printf("\n--- Ha ingresado al sistema de cantidad de fallas ---\n");
	printf("Ingrese la cantidad de fallas del veh�culo: ");
	scanf("%d", &cantidadFallas);
	printf("Gracias por la informaci�n. Puede continuar con la matriculaci�n.\n");
}
