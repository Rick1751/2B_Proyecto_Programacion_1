#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "validaciones.h"

// Variables globales definidas
char cedula[11];
char numeroPlaca[11];

//----Declaraci�n de funciones para validar los datos del usuario----

//Funci�n para validar la edad del due�o del veh�culo

int validarEdadPropietario() {
	int edad;
	
	while(1) {  // Bucle infinito hasta que la edad sea válida y mayor de edad
		printf("Ingrese la edad del propietario: ");
		scanf("%d", &edad);
		
		if(edad <= 0 || edad > 120) {
			printf("Edad no válida. Ingrese de nuevo.\n");
		} 
		else if(edad < 18) {
			printf("El propietario es menor de edad. Ingrese de nuevo.\n");
		} 
		else {
			printf("Edad registrada correctamente.\n");
			return edad;  // Retorna la edad válida
		}
	}
}

//Funci�n que valida la longitud m�nima y m�xima de la cadena de texto para ingresar un nombre

bool validarNombre(const char *nombre) {
	
	// Valida que el puntero no sea nulo
	if (nombre == NULL) return false;  
	
	int longitud = strlen(nombre); 
	
	//Validaci�n de la longitud de la cadena de texto
	if (longitud == 0) {
		// Nombre vac�o
		return false;  
	} else if (longitud < 10 || longitud > 60) {
		// El nombre supera el m�ximo de d�gitos permitidos
		return false;  
	}
	// El nombre es v�lido
	return true;  
}

// Validaci�n de c�dula: longitud == 10 y solo n�meros
void validarCedula() {
	int esValida = 1;
	
	if (strlen(cedula) != 10) {
		esValida = 0;
	} else {
		for (int i = 0; i < 10; i++) {
			if (!isdigit(cedula[i])) {
				esValida = 0;
				break;
			}
		}
	}
	
	if (!esValida) {
		printf("El n�mero de c�dula del propietario es inv�lido. Ingrese un documento v�lido.\n");
	} else {
		printf("El n�mero de c�dula ha sido registrado correctamente.\n");
	}
}


// ----Declaraci�n de funciones para validar los datos del veh�culo----

// Funci�n para validar la placa del veh�culo

void validarPlaca() {
	if (strlen(numeroPlaca) != 7) {
		printf("Ingrese un n�mero de placa v�lido.\n");
	} else {
		printf("Placa registrada con �xito.\n");
	}
}

//Funci�n para validar la placa del veh�culo

int validarModeloAuto(const char* modeloAuto) {
	// Validar que el puntero no sea nulo
	if (modeloAuto == NULL) {
		printf("Error: Modelo no proporcionado\n");
		return 0;
	}
	
	// Calcular longitud del de la cadena de texto para el modelo de  auto
	int longitud = strlen(modeloAuto);
	
	// Validar longitud m�nima y m�xima
	if (longitud < 5 || longitud > 25) {
		printf("El modelo debe tener entre 5 y 25 caracteres. Ingrese un modelo adecuado.\n");
		return 0;
	}
	
	// Validar que no sea una cadena vac�a o solo espacios
	int soloEspacios = 1;
	for (int i = 0; modeloAuto[i] != '\0'; i++) {
		if (modeloAuto[i] != ' ') {
			soloEspacios = 0;
			break;
		}
	}
	
	if (soloEspacios) {
		printf("El modelo no puede contener solo espacios.\n");
		return 0;
	}
	
	printf("El modelo del vehículo se ha registrado exitosamente.\n");
	return 1;
}


