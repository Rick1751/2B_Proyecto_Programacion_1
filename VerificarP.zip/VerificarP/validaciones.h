#ifndef VALIDACIONES_H
#define VALIDACIONES_H
#include <stdbool.h>
// Declaraciones de variables globales
extern char cedula[11];
extern char numeroPlaca[11];

//----Declaraci�n de funciones para validar los datos del usuario----

// Funci�n que valida la edad y retorna la edad v�lida (>=18 y <=120)
int validarEdadPropietario();

// Funci�n que valida el nombre del propietario
bool validarNombre(const char *nombre);

//Funci�n para validar la c�dula del propietario del veh�culo
void validarCedula();


// ----Declaraci�n de funciones para validar los datos del veh�culo----

//Funci�n para validar la placa del veh�culo
void validarPlaca();

/*
* Funci�n que valida la longitud de la cadena de texto para el modelo de auto
* @return 1 si es v�lido, 0 si no cumple con la longitud requerida
*/
int validarModeloAuto(const char* modeloAuto);




#endif
