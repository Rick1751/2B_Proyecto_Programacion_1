#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdbool.h>
#include "validaciones.h"
#include "menu.h"

//Variables globales

extern char cedula[11];
extern char numeroPlaca[11];

//Funci�n para cuando se seleccione el men� de opciones 

void usarMenuPrincipal() {
	int opcion;
	
	do {
		menuPrincipal();
		printf("IIngrese la opci�n a la que desea ingresar")
		scanf("%d", &opcion);
		
		// Limpiar el buffer de entrada es decir coloca la pantalla en blanco de nuevo
		while(getchar() != '\n');
		
		switch(opcion) {
		case 1:
			printf("\nIngresando a la opci�n 1...\n");
			// C�digo para la opci�n 1
			break;
		case 2:
			printf("\nIngresando a la opci�n 2...\n");
			// C�digo para la opci�n 2
			break;
		case 3:
			printf("\nIngresando a la opci�n 3...\n");
			// C�digo para la opci�n 3
			break;
		case 4:
			printf("\nIngresando a la opci�n 4...\n");
			// C�digo para la opci�n 4
			break;
		case 5:
			printf("\nIngresando a la opci�n 5...\n");
			// C�digo para la opci�n 5
			break;
		case 6:
			printf("\nIngresando a la opci�n 6...\n");
			// C�digo para la opci�n 6
			break;
		case 7:
			printf("\nIngresando a la opci�n 7...\n");
			// C�digo para la opci�n 7
			break;
		case 8:
			printf("\nSaliendo del programa, gracias por elegui VerifiCar como su asistente de confianza...\n");
			break;
		default:
			printf("\nOpci�n no v�lida. Por favor ingrese un n�mero del 1 al 8.\n");
		}
		
	} while(opcion != 8);
}


//Implementacion de la funci�n principal main

int main() {
	// Invocaci�n de la Funci�n para eleguir una opci�n del men�
	usarMenuPrincipal();
	return 0;
}



